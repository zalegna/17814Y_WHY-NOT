Control
=======

.. doxygenclass:: dlib::Pid
    :project: dlib
    :members:

.. doxygenstruct:: dlib::PidGains
    :project: dlib
    :members:

.. doxygenclass:: dlib::Feedforward
    :project: dlib
    :members:

.. doxygenstruct:: dlib::FeedforwardGains
    :project: dlib
    :members:

.. doxygenclass:: dlib::ErrorTimeSettler
    :project: dlib
    :members:

.. doxygenclass:: dlib::ErrorDerivativeSettler
    :project: dlib
    :members:

