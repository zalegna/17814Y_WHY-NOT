Trajectories
============

.. doxygenclass:: dlib::TrapezoidProfile
    :project: dlib
    :members: